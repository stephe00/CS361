#StephenOium
#Passwords.py
#361
#code

from flask import Flask
app = Flask(__name__)

username_password = {"test": "test"}

@app.route('/<username>/<password>')
def check_credentials():
  print("Checking username and password against a database")
  if username in username_password and username_password[username] == password:
    return True
  else:
    return False

if __name__ = '__main__':
    app.run(debug True, port=8000)

